class StorageManager {
    static async getTopics() {
        try {
            console.log('Getting topics from storage...');
            // For Chrome extension environment
            if (typeof chrome !== 'undefined' && chrome.storage) {
                console.log('Using Chrome storage API');
                const result = await chrome.storage.local.get('topics');
                console.log('Retrieved topics:', result.topics || []);
                return result.topics || [];
            }
            // For development/testing environment
            console.log('Using mock storage');
            if (!window._mockStorage) {
                window._mockStorage = { topics: [] };
            }
            return window._mockStorage.topics;
        } catch (error) {
            console.error('Error getting topics:', error);
            throw new Error('Failed to get topics: ' + error.message);
        }
    }

    static async saveTopic(topic) {
        try {
            console.log('Saving new topic:', topic);
            const topics = await this.getTopics();
            const newTopic = {
                id: Date.now().toString(),
                name: topic.name,
                color: topic.color,
                items: []
            };
            topics.push(newTopic);

            if (typeof chrome !== 'undefined' && chrome.storage) {
                console.log('Saving to Chrome storage');
                await chrome.storage.local.set({ topics });
            } else {
                console.log('Saving to mock storage');
                window._mockStorage.topics = topics;
            }
            console.log('Topic saved successfully');
            return topics;
        } catch (error) {
            console.error('Error saving topic:', error);
            throw new Error('Failed to save topic: ' + error.message);
        }
    }

    static async deleteTopic(topicId) {
        try {
            console.log('Deleting topic:', topicId);
            const topics = await this.getTopics();
            const updatedTopics = topics.filter(topic => topic.id !== topicId);

            if (typeof chrome !== 'undefined' && chrome.storage) {
                await chrome.storage.local.set({ topics: updatedTopics });
            } else {
                window._mockStorage.topics = updatedTopics;
            }
            console.log('Topic deleted successfully');
            return updatedTopics;
        } catch (error) {
            console.error('Error deleting topic:', error);
            throw new Error('Failed to delete topic: ' + error.message);
        }
    }

    static async addItem(topicId, item) {
        try {
            console.log('Adding item to topic:', topicId, item);
            const topics = await this.getTopics();
            const topic = topics.find(t => t.id === topicId);

            if (!topic) {
                throw new Error('Topic not found');
            }

            const newItem = {
                id: Date.now().toString(),
                name: item.name,
                url: item.url
            };

            topic.items.push(newItem);

            if (typeof chrome !== 'undefined' && chrome.storage) {
                await chrome.storage.local.set({ topics });
            } else {
                window._mockStorage.topics = topics;
            }
            console.log('Item added successfully');
            return topics;
        } catch (error) {
            console.error('Error adding item:', error);
            throw new Error('Failed to add item: ' + error.message);
        }
    }

    static async deleteItem(topicId, itemId) {
        try {
            console.log('Deleting item:', itemId, 'from topic:', topicId);
            const topics = await this.getTopics();
            const topic = topics.find(t => t.id === topicId);

            if (!topic) {
                throw new Error('Topic not found');
            }

            topic.items = topic.items.filter(item => item.id !== itemId);

            if (typeof chrome !== 'undefined' && chrome.storage) {
                await chrome.storage.local.set({ topics });
            } else {
                window._mockStorage.topics = topics;
            }
            console.log('Item deleted successfully');
            return topics;
        } catch (error) {
            console.error('Error deleting item:', error);
            throw new Error('Failed to delete item: ' + error.message);
        }
    }

    static isValidUrl(url) {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    }
}

// Make StorageManager available globally
window.StorageManager = StorageManager;