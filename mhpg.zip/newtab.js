console.log('Loading newtab.js...');

class TopicManager {
    constructor() {
        console.log('Initializing TopicManager...');
        this.addTopicDialog = document.getElementById('addTopicDialog');
        this.addItemDialog = document.getElementById('addItemDialog');
        this.topicsContainer = document.getElementById('topicsContainer');

        if (!this.addTopicDialog) console.error('addTopicDialog not found');
        if (!this.addItemDialog) console.error('addItemDialog not found');
        if (!this.topicsContainer) console.error('topicsContainer not found');

        this.setupEventListeners();
        this.loadTopics();
        console.log('TopicManager initialization complete');
    }

    setupEventListeners() {
        console.log('Setting up event listeners...');
        // Add Topic Button
        const addTopicBtn = document.getElementById('addTopicBtn');
        if (addTopicBtn) {
            addTopicBtn.addEventListener('click', () => {
                console.log('Add Topic button clicked');
                if (this.addTopicDialog) {
                    this.addTopicDialog.showModal();
                } else {
                    console.error('Add Topic dialog not found');
                }
            });
        } else {
            console.error('Add Topic button not found');
        }

        // Add Topic Form
        const addTopicForm = document.getElementById('addTopicForm');
        if (addTopicForm) {
            addTopicForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                console.log('Topic form submitted');
                try {
                    await this.handleAddTopic();
                } catch (error) {
                    console.error('Failed to add topic:', error);
                    alert('Failed to add topic: ' + error.message);
                }
            });
        } else {
            console.error('Add Topic form not found');
        }

        // Add Item Form
        const addItemForm = document.getElementById('addItemForm');
        if (addItemForm) {
            addItemForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                console.log('Item form submitted');
                try {
                    await this.handleAddItem();
                } catch (error) {
                    console.error('Failed to add item:', error);
                    alert('Failed to add item: ' + error.message);
                }
            });
        }

        // Close dialogs when clicking outside
        [this.addTopicDialog, this.addItemDialog].forEach(dialog => {
            if (dialog) {
                dialog.addEventListener('click', (e) => {
                    if (e.target === dialog) {
                        dialog.close();
                    }
                });
            }
        });

        // Add event delegation for delete and add link buttons
        this.topicsContainer.addEventListener('click', async (e) => {
            const target = e.target;

            // Handle delete topic button
            if (target.closest('.delete-topic-btn')) {
                const topicId = target.closest('.delete-topic-btn').dataset.topicId;
                await this.handleDeleteTopic(topicId);
            }

            // Handle delete item button
            if (target.closest('.delete-item-btn')) {
                const topicId = target.closest('.delete-item-btn').dataset.topicId;
                const itemId = target.closest('.delete-item-btn').dataset.itemId;
                await this.handleDeleteItem(topicId, itemId);
            }

            // Handle add link button
            if (target.closest('.add-link-btn')) {
                const topicId = target.closest('.add-link-btn').dataset.topicId;
                this.showAddItemDialog(topicId);
            }
        });

        console.log('Event listeners setup complete');
    }

    async loadTopics() {
        try {
            console.log('Loading topics...');
            const topics = await StorageManager.getTopics();
            console.log('Topics loaded:', topics);
            this.renderTopics(topics);
        } catch (error) {
            console.error('Failed to load topics:', error);
            this.topicsContainer.innerHTML = '<p class="error">Failed to load topics. Please refresh the page.</p>';
        }
    }

    async handleAddTopic() {
        const nameInput = document.getElementById('topicName');
        const colorInput = document.getElementById('topicColor');

        const name = nameInput.value.trim();
        if (!name) {
            throw new Error('Topic name is required');
        }

        console.log('Adding new topic:', name);
        const topic = {
            name: name,
            color: colorInput.value
        };

        const topics = await StorageManager.saveTopic(topic);
        this.renderTopics(topics);
        this.addTopicDialog.close();
        nameInput.value = '';
    }

    async handleAddItem() {
        const topicId = document.getElementById('topicId').value;
        const nameInput = document.getElementById('itemName');
        const urlInput = document.getElementById('itemUrl');

        const name = nameInput.value.trim();
        const url = urlInput.value.trim();

        if (!name) {
            throw new Error('Item name is required');
        }

        if (!StorageManager.isValidUrl(url)) {
            throw new Error('Please enter a valid URL');
        }

        console.log('Adding new item to topic:', topicId);
        const item = { name, url };
        const topics = await StorageManager.addItem(topicId, item);
        this.renderTopics(topics);
        this.addItemDialog.close();
        nameInput.value = '';
        urlInput.value = '';
    }

    async handleDeleteTopic(topicId) {
        console.log('Attempting to delete topic:', topicId);
        if (confirm('Are you sure you want to delete this topic?')) {
            try {
                const topics = await StorageManager.deleteTopic(topicId);
                this.renderTopics(topics);
            } catch (error) {
                console.error('Failed to delete topic:', error);
                alert('Failed to delete topic: ' + error.message);
            }
        }
    }

    async handleDeleteItem(topicId, itemId) {
        console.log('Attempting to delete item:', itemId, 'from topic:', topicId);
        if (confirm('Are you sure you want to delete this item?')) {
            try {
                const topics = await StorageManager.deleteItem(topicId, itemId);
                this.renderTopics(topics);
            } catch (error) {
                console.error('Failed to delete item:', error);
                alert('Failed to delete item: ' + error.message);
            }
        }
    }

    showAddItemDialog(topicId) {
        console.log('Showing add item dialog for topic:', topicId);
        document.getElementById('topicId').value = topicId;
        this.addItemDialog.showModal();
    }

    createTopicCard(topic) {
        return `
            <div class="topic-card">
                <div class="topic-header" style="border-color: ${topic.color}">
                    <h3 class="topic-title">${this.escapeHtml(topic.name)}</h3>
                    <div class="topic-actions">
                        <button class="btn primary add-link-btn" data-topic-id="${topic.id}">
                            Add Link
                        </button>
                        <button class="delete-btn delete-topic-btn" data-topic-id="${topic.id}">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="topic-items">
                    ${topic.items.length === 0 
                        ? '<p class="empty-state">No links yet. Click "Add Link" to add one.</p>'
                        : topic.items.map(item => this.createLinkItem(topic.id, item)).join('')}
                </div>
            </div>
        `;
    }

    createLinkItem(topicId, item) {
        return `
            <div class="link-item">
                <a href="${this.escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer">
                    ${this.escapeHtml(item.name)}
                </a>
                <button class="delete-btn delete-item-btn" data-topic-id="${topicId}" data-item-id="${item.id}">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 6L6 18M6 6l12 12"/>
                    </svg>
                </button>
            </div>
        `;
    }

    renderTopics(topics) {
        console.log('Rendering topics:', topics);
        this.topicsContainer.innerHTML = topics.length === 0 
            ? '<p class="empty-state">No topics yet. Click "Add Topic" to get started.</p>'
            : topics.map(topic => this.createTopicCard(topic)).join('');
    }

    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
}

// Initialize TopicManager only after DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing TopicManager');
    window.topicManager = new TopicManager();
});